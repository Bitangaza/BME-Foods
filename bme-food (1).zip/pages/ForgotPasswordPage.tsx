
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock logic
    setIsSent(true);
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center">
      <div className="w-full max-w-md glass p-10 rounded-[2.5rem] shadow-2xl relative">
        {!isSent ? (
          <>
            <div className="text-center mb-10">
              <div className="bg-orange-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-key text-2xl"></i>
              </div>
              <h1 className="text-3xl font-extrabold mb-2">Forgot Password?</h1>
              <p className="opacity-60">Enter your email and we'll send you a link to reset your password.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold opacity-80 ml-2">Email Address</label>
                <input 
                  type="email" required
                  className="w-full bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
                  placeholder="you@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                />
              </div>

              <button 
                type="submit"
                className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-bold text-lg transition shadow-xl transform hover:-translate-y-1"
              >
                Send Reset Link
              </button>
            </form>
          </>
        ) : (
          <div className="text-center py-10 space-y-6 animate-fadeIn">
            <div className="bg-green-500/20 text-green-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto text-4xl">
              <i className="fas fa-paper-plane"></i>
            </div>
            <h1 className="text-3xl font-extrabold">Check Your Email</h1>
            <p className="opacity-60">We've sent a password reset link to <br /><span className="text-white font-bold">{email}</span></p>
            <button 
              onClick={() => setIsSent(false)}
              className="text-orange-400 font-bold hover:underline"
            >
              Didn't receive it? Try again
            </button>
          </div>
        )}

        <div className="mt-8 text-center pt-8 border-t border-white/5">
          <Link to="/login" className="text-sm font-bold flex items-center justify-center gap-2 hover:text-orange-400 transition">
            <i className="fas fa-arrow-left"></i> Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
