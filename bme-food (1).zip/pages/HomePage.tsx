
import React from 'react';
import { Link } from 'react-router-dom';

const HomePage: React.FC = () => {
  return (
    <div className="space-y-20 py-12">
      {/* Hero Section */}
      <section className="flex flex-col md:flex-row items-center justify-between gap-12 pt-10">
        <div className="md:w-1/2 space-y-6 text-center md:text-left">
          <h1 className="text-5xl lg:text-7xl font-extrabold leading-tight">
            Delicious Food <br /> 
            <span className="text-orange-500">Delivered Fast</span>
          </h1>
          <p className="text-xl opacity-80 max-w-lg mx-auto md:mx-0">
            Experience international flavors with BME Food. From breakfast to premium wines, we bring the world to your table.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start pt-4">
            <Link 
              to="/menu" 
              className="px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl text-xl font-bold transition shadow-2xl shadow-orange-900/40 transform hover:-translate-y-1"
            >
              Order Now <i className="fas fa-arrow-right ml-2"></i>
            </Link>
            <Link 
              to="/menu" 
              className="px-8 py-4 glass hover:bg-white/10 rounded-2xl text-xl font-bold transition transform hover:-translate-y-1"
            >
              View Menu
            </Link>
          </div>
          <div className="flex items-center gap-6 pt-8 justify-center md:justify-start opacity-70">
            <div className="text-center">
              <p className="text-3xl font-bold">50+</p>
              <p className="text-sm">Dishes</p>
            </div>
            <div className="w-px h-10 bg-white/20"></div>
            <div className="text-center">
              <p className="text-3xl font-bold">20+</p>
              <p className="text-sm">Countries</p>
            </div>
            <div className="w-px h-10 bg-white/20"></div>
            <div className="text-center">
              <p className="text-3xl font-bold">10k</p>
              <p className="text-sm">Users</p>
            </div>
          </div>
        </div>

        <div className="md:w-1/2 relative">
          <div className="absolute -inset-4 bg-orange-600/30 blur-3xl rounded-full"></div>
          <img 
            src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=1000" 
            alt="Hero Dish" 
            className="relative w-full h-[500px] object-cover rounded-[3rem] shadow-2xl transform hover:scale-105 transition duration-700"
          />
          <div className="absolute -bottom-6 -left-6 glass p-4 rounded-2xl animate-bounce shadow-xl">
            <div className="flex items-center gap-3">
              <div className="bg-orange-500 p-2 rounded-lg">
                <i className="fas fa-bolt"></i>
              </div>
              <div>
                <p className="font-bold">Super Fast</p>
                <p className="text-xs opacity-70">Delivery within 20 mins</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="space-y-12">
        <h2 className="text-4xl font-bold text-center">Popular Categories</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { name: 'Breakfast', icon: 'fa-coffee', img: 'https://images.unsplash.com/photo-149485981460c-3810c30a1b4e?auto=format&fit=crop&q=80&w=600' },
            { name: 'Lunch', icon: 'fa-utensils', img: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=600' },
            { name: 'Dinner', icon: 'fa-moon', img: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&q=80&w=600' },
            { name: 'Drinks', icon: 'fa-glass-cheers', img: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&q=80&w=600' },
          ].map(cat => (
            <Link to={`/menu?cat=${cat.name}`} key={cat.name} className="group relative overflow-hidden rounded-[2rem] h-64 glass cursor-pointer shadow-lg hover:shadow-orange-500/20 transition-all duration-500">
              <img 
                src={cat.img} 
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" 
                alt={cat.name}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-8">
                <i className={`fas ${cat.icon} text-3xl text-orange-500 mb-2`}></i>
                <h3 className="text-2xl font-bold">{cat.name}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="glass p-12 rounded-[3rem] text-center space-y-12">
        <h2 className="text-4xl font-bold">Why BME Food?</h2>
        <div className="grid md:grid-cols-3 gap-12">
          <div className="space-y-4">
            <div className="w-16 h-16 bg-orange-500/20 text-orange-500 rounded-2xl flex items-center justify-center text-3xl mx-auto">
              <i className="fas fa-globe"></i>
            </div>
            <h3 className="text-2xl font-bold">International</h3>
            <p className="opacity-70">Support for multiple countries, currencies and phone formats.</p>
          </div>
          <div className="space-y-4">
            <div className="w-16 h-16 bg-blue-500/20 text-blue-500 rounded-2xl flex items-center justify-center text-3xl mx-auto">
              <i className="fas fa-mobile-alt"></i>
            </div>
            <h3 className="text-2xl font-bold">Mobile Money</h3>
            <p className="opacity-70">MTN and Airtel integrated logic for seamless local transactions.</p>
          </div>
          <div className="space-y-4">
            <div className="w-16 h-16 bg-green-500/20 text-green-500 rounded-2xl flex items-center justify-center text-3xl mx-auto">
              <i className="fas fa-shield-alt"></i>
            </div>
            <h3 className="text-2xl font-bold">Secure</h3>
            <p className="opacity-70">Advanced JWT authentication and encrypted user data handling.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
