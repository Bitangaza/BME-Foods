
import React, { useState } from 'react';
/* Add missing import for Link */
import { Link } from 'react-router-dom';
import { User } from '../types';

interface ProfilePageProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, setUser }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ ...user });

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    setUser(editData);
    localStorage.setItem('bme_user', JSON.stringify(editData));
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto py-10 space-y-12">
      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="relative group">
          <img 
            src={`https://ui-avatars.com/api/?name=${user.firstName}+${user.lastName}&background=f97316&color=fff&size=200`}
            alt="Avatar"
            className="w-48 h-48 rounded-[3rem] shadow-2xl border-4 border-white/20"
          />
          <button className="absolute bottom-4 right-4 bg-orange-600 p-3 rounded-2xl shadow-lg hover:scale-110 transition opacity-0 group-hover:opacity-100">
            <i className="fas fa-camera"></i>
          </button>
        </div>
        <div className="text-center md:text-left space-y-2">
          <span className="bg-orange-600/20 text-orange-500 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">{user.role}</span>
          <h1 className="text-5xl font-extrabold">{user.firstName} {user.lastName}</h1>
          <p className="opacity-60 text-lg flex items-center justify-center md:justify-start gap-2">
            <i className="fas fa-envelope"></i> {user.email}
          </p>
          <p className="opacity-60 text-lg flex items-center justify-center md:justify-start gap-2">
            <i className="fas fa-phone"></i> {user.phone}
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="glass p-10 rounded-[2.5rem] space-y-6 shadow-xl">
          <h2 className="text-2xl font-bold border-b border-white/10 pb-4">Personal Information</h2>
          {!isEditing ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs uppercase opacity-40 font-bold mb-1">First Name</p>
                  <p className="font-semibold text-lg">{user.firstName}</p>
                </div>
                <div>
                  <p className="text-xs uppercase opacity-40 font-bold mb-1">Last Name</p>
                  <p className="font-semibold text-lg">{user.lastName}</p>
                </div>
                <div>
                  <p className="text-xs uppercase opacity-40 font-bold mb-1">Country</p>
                  <p className="font-semibold text-lg">{user.country}</p>
                </div>
                <div>
                  <p className="text-xs uppercase opacity-40 font-bold mb-1">Role</p>
                  <p className="font-semibold text-lg capitalize">{user.role}</p>
                </div>
              </div>
              <button 
                onClick={() => setIsEditing(true)}
                className="w-full py-4 glass hover:bg-white/10 rounded-2xl font-bold transition flex items-center justify-center gap-2"
              >
                <i className="fas fa-edit"></i> Edit Profile
              </button>
            </div>
          ) : (
            <form onSubmit={handleUpdate} className="space-y-4">
               <div className="grid grid-cols-2 gap-4">
                <input 
                  className="bg-white/5 border border-white/10 p-4 rounded-xl outline-none" 
                  value={editData.firstName} 
                  onChange={e => setEditData({...editData, firstName: e.target.value})}
                />
                <input 
                  className="bg-white/5 border border-white/10 p-4 rounded-xl outline-none" 
                  value={editData.lastName} 
                  onChange={e => setEditData({...editData, lastName: e.target.value})}
                />
              </div>
              <input 
                className="w-full bg-white/5 border border-white/10 p-4 rounded-xl outline-none" 
                value={editData.email} 
                onChange={e => setEditData({...editData, email: e.target.value})}
              />
              <div className="flex gap-4">
                <button type="button" onClick={() => setIsEditing(false)} className="flex-grow py-3 glass rounded-xl">Cancel</button>
                <button type="submit" className="flex-grow py-3 bg-orange-600 rounded-xl font-bold">Update</button>
              </div>
            </form>
          )}
        </div>

        <div className="glass p-10 rounded-[2.5rem] space-y-6 shadow-xl">
          <h2 className="text-2xl font-bold border-b border-white/10 pb-4">Order History</h2>
          <div className="flex flex-col items-center justify-center h-48 opacity-40 space-y-4">
            <i className="fas fa-history text-5xl"></i>
            <p className="text-lg">No orders yet.</p>
            {/* Fix: use Link from react-router-dom */}
            <Link to="/menu" className="text-orange-400 font-bold hover:underline">Start Ordering Now</Link>
          </div>
        </div>
      </div>

      <div className="glass p-10 rounded-[2.5rem] shadow-xl text-center">
        <h2 className="text-2xl font-bold mb-4">Refer a Friend</h2>
        <p className="opacity-70 mb-8 max-w-md mx-auto">Share your referral link with your friends and get a free meal for every 3 referrals!</p>
        <div className="flex bg-black/20 rounded-2xl p-2 max-w-md mx-auto">
          <input 
            readOnly 
            value="bmefood.com/ref/john-doe-123" 
            className="bg-transparent flex-grow px-4 outline-none text-orange-400 font-mono"
          />
          <button className="bg-orange-600 hover:bg-orange-700 px-6 py-3 rounded-xl font-bold transition">Copy</button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
