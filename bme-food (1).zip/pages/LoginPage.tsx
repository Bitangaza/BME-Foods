
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Role } from '../types';

interface LoginPageProps {
  onLogin: (u: User) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Mock Login Logic
    if (email === 'admin@bme.com' && password === 'admin') {
      onLogin({
        id: 'admin-1',
        firstName: 'System',
        lastName: 'Admin',
        email: 'admin@bme.com',
        phone: '0000000000',
        country: 'USA',
        role: Role.ADMIN
      });
      navigate('/admin');
    } else if (email && password.length >= 4) {
      onLogin({
        id: 'user-' + Date.now(),
        firstName: email.split('@')[0],
        lastName: 'User',
        email,
        phone: '1234567890',
        country: 'USA',
        role: Role.USER
      });
      navigate('/menu');
    } else {
      setError('Invalid credentials. Try admin@bme.com / admin');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <div className="w-full max-w-md glass p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 to-yellow-500"></div>
        
        <div className="text-center mb-10">
          <div className="bg-orange-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-orange-900/40">
            <span className="font-bold text-2xl">BME</span>
          </div>
          <h1 className="text-3xl font-extrabold mb-2">Welcome Back</h1>
          <p className="opacity-60">Log in to your BME Food account</p>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500/30 p-4 rounded-xl mb-6 flex items-center gap-3 animate-shake">
            <i className="fas fa-exclamation-circle text-red-500"></i>
            <p className="text-sm">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">Email Address</label>
            <div className="relative">
              <i className="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 opacity-40"></i>
              <input 
                type="email" 
                required
                className="w-full bg-white/5 border border-white/10 pl-12 pr-4 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white/10 outline-none transition"
                placeholder="you@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center ml-2">
              <label className="text-sm font-semibold opacity-80">Password</label>
              <Link to="/forgot-password" size="sm" className="text-xs text-orange-400 hover:text-orange-300 font-bold">Forgot?</Link>
            </div>
            <div className="relative">
              <i className="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 opacity-40"></i>
              <input 
                type="password" 
                required
                className="w-full bg-white/5 border border-white/10 pl-12 pr-4 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white/10 outline-none transition"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-bold text-lg transition shadow-xl shadow-orange-900/40 transform hover:-translate-y-1"
          >
            Sign In
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="opacity-60 text-sm">
            Don't have an account? <Link to="/register" className="text-orange-400 font-bold hover:underline">Sign up for free</Link>
          </p>
        </div>

        <div className="mt-8 pt-8 border-t border-white/5 text-center">
          <p className="text-xs opacity-40 mb-4 uppercase tracking-widest font-bold">Or connect with</p>
          <div className="flex justify-center gap-4">
            <button className="w-12 h-12 glass rounded-xl flex items-center justify-center hover:bg-white/20 transition">
              <i className="fab fa-google text-xl text-red-500"></i>
            </button>
            <button className="w-12 h-12 glass rounded-xl flex items-center justify-center hover:bg-white/20 transition">
              <i className="fab fa-apple text-xl"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
