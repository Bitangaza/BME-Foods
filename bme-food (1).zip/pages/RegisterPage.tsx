
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Role } from '../types';
import { COUNTRIES } from '../constants';

interface RegisterPageProps {
  onLogin: (u: User) => void;
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    phone: '',
    country: 'USA'
  });
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API registration
    const newUser: User = {
      id: 'user-' + Date.now(),
      ...formData,
      role: Role.USER
    };
    onLogin(newUser);
    navigate('/menu');
  };

  const selectedCountry = COUNTRIES.find(c => c.name === formData.country);

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-10">
      <div className="w-full max-w-2xl glass p-10 rounded-[2.5rem] shadow-2xl relative">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-extrabold mb-2">Create Account</h1>
          <p className="opacity-60">Join BME Food for an international dining experience</p>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">First Name</label>
            <input 
              type="text" required
              className="w-full bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
              placeholder="John"
              value={formData.firstName}
              onChange={e => setFormData({...formData, firstName: e.target.value})}
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">Last Name</label>
            <input 
              type="text" required
              className="w-full bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
              placeholder="Doe"
              value={formData.lastName}
              onChange={e => setFormData({...formData, lastName: e.target.value})}
            />
          </div>

          <div className="md:col-span-2 space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">Email Address</label>
            <input 
              type="email" required
              className="w-full bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
              placeholder="john@example.com"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">Country</label>
            <select 
              className="w-full bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition appearance-none"
              value={formData.country}
              onChange={e => setFormData({...formData, country: e.target.value})}
            >
              {COUNTRIES.map(c => <option key={c.name} value={c.name} className="bg-neutral-900">{c.name}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">Phone Number</label>
            <div className="flex gap-2">
              <span className="bg-white/10 px-4 py-4 rounded-2xl flex items-center font-bold">{selectedCountry?.code}</span>
              <input 
                type="tel" required
                className="flex-grow bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
                placeholder="123 456 789"
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
              />
            </div>
          </div>

          <div className="md:col-span-2 space-y-2">
            <label className="text-sm font-semibold opacity-80 ml-2">Password</label>
            <input 
              type="password" required minLength={8}
              className="w-full bg-white/5 border border-white/10 px-6 py-4 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
              placeholder="Choose a strong password"
              value={formData.password}
              onChange={e => setFormData({...formData, password: e.target.value})}
            />
          </div>

          <div className="md:col-span-2 flex items-center gap-3 py-2 px-2">
            <input type="checkbox" required className="w-5 h-5 rounded-md accent-orange-500" />
            <span className="text-sm opacity-70">I agree to the <a href="#" className="text-orange-400 underline">Terms of Service</a> and Privacy Policy</span>
          </div>

          <button 
            type="submit"
            className="md:col-span-2 py-5 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-bold text-xl transition shadow-xl shadow-orange-900/40 transform hover:-translate-y-1"
          >
            Create My Account
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="opacity-60">
            Already have an account? <Link to="/login" className="text-orange-400 font-bold hover:underline">Log in here</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
