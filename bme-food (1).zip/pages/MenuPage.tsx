
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Product, Category } from '../types';
import { CATEGORIES } from '../constants';
import { suggestDishes } from '../services/geminiService';

interface MenuPageProps {
  products: Product[];
  addToCart: (p: Product) => void;
}

const MenuPage: React.FC<MenuPageProps> = ({ products, addToCart }) => {
  const [searchParams] = useSearchParams();
  const [activeCategory, setActiveCategory] = useState<string>(searchParams.get('cat') || 'All');
  const [searchTerm, setSearchTerm] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState<any[]>([]);
  const [isSuggesting, setIsSuggesting] = useState(false);

  const filteredProducts = products.filter(p => {
    const matchesCat = activeCategory === 'All' || p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleAskAI = async () => {
    const pref = prompt("What are you in the mood for? (e.g., 'Something spicy with seafood' or 'Healthy vegan breakfast')");
    if (!pref) return;

    setIsSuggesting(true);
    const suggestions = await suggestDishes(pref);
    setAiSuggestions(suggestions);
    setIsSuggesting(false);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <h1 className="text-4xl font-extrabold">Explore Our <span className="text-orange-500">Menu</span></h1>
        
        <div className="flex w-full md:w-auto gap-4">
          <div className="relative flex-grow md:w-80">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 opacity-50"></i>
            <input 
              type="text" 
              placeholder="Search dishes..."
              className="w-full pl-12 pr-4 py-3 glass rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none transition"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button 
            onClick={handleAskAI}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-2xl flex items-center gap-2 transition shadow-xl"
            disabled={isSuggesting}
          >
            {isSuggesting ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-magic"></i>}
            <span className="hidden sm:inline">Ask AI</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex overflow-x-auto pb-4 gap-4 no-scrollbar">
        <button 
          onClick={() => setActiveCategory('All')}
          className={`px-8 py-3 rounded-full font-bold whitespace-nowrap transition ${activeCategory === 'All' ? 'bg-orange-600 shadow-lg shadow-orange-900/40' : 'glass hover:bg-white/10'}`}
        >
          All Items
        </button>
        {CATEGORIES.map(cat => (
          <button 
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-8 py-3 rounded-full font-bold whitespace-nowrap transition ${activeCategory === cat ? 'bg-orange-600 shadow-lg shadow-orange-900/40' : 'glass hover:bg-white/10'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* AI Suggestions Row */}
      {aiSuggestions.length > 0 && (
        <div className="glass p-6 rounded-[2rem] border-2 border-purple-500/30">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <i className="fas fa-robot text-purple-400"></i>
              Chef Gemini's Recommendations
            </h2>
            <button onClick={() => setAiSuggestions([])} className="text-sm opacity-50 hover:opacity-100">Clear</button>
          </div>
          <div className="grid sm:grid-cols-3 gap-6">
            {aiSuggestions.map((s, idx) => (
              <div key={idx} className="bg-purple-900/20 p-5 rounded-2xl border border-purple-500/20">
                <span className="text-[10px] font-bold uppercase tracking-widest text-purple-400">{s.category}</span>
                <h3 className="text-xl font-bold mt-1">{s.name}</h3>
                <p className="text-sm opacity-70 mt-2 line-clamp-2">{s.description}</p>
                <button 
                  onClick={() => addToCart({ ...products[0], name: s.name, description: s.description, category: s.category as Category, id: 'ai-' + idx })}
                  className="mt-4 text-purple-400 font-bold text-sm flex items-center gap-2 hover:translate-x-1 transition-transform"
                >
                  Add Mock to Cart <i className="fas fa-plus-circle"></i>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredProducts.map(p => (
          <div key={p.id} className="group glass rounded-[2.5rem] overflow-hidden flex flex-col shadow-xl hover:shadow-orange-500/10 transition-all duration-500 hover:-translate-y-2">
            <div className="relative h-60 overflow-hidden">
              <img 
                src={p.image} 
                alt={p.name} 
                className="w-full h-full object-cover group-hover:scale-110 transition duration-700"
              />
              <div className="absolute top-4 right-4 glass px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                {p.category}
              </div>
              {!p.isAvailable && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex items-center justify-center font-bold text-xl uppercase tracking-widest">
                  Unavailable
                </div>
              )}
            </div>
            
            <div className="p-8 flex flex-grow flex-col">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-2xl font-bold group-hover:text-orange-500 transition">{p.name}</h3>
                <p className="text-xl font-bold text-orange-500">${p.price.toFixed(2)}</p>
              </div>
              <p className="text-sm opacity-60 flex-grow mb-6 line-clamp-2">{p.description}</p>
              
              <button 
                onClick={() => addToCart(p)}
                disabled={!p.isAvailable}
                className="w-full py-4 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-700 disabled:opacity-50 text-white rounded-2xl font-bold transition flex items-center justify-center gap-2 shadow-lg shadow-orange-900/20"
              >
                <i className="fas fa-plus"></i> Add to Order
              </button>
            </div>
          </div>
        ))}

        {filteredProducts.length === 0 && (
          <div className="col-span-full py-20 text-center glass rounded-[2rem]">
            <i className="fas fa-search text-6xl opacity-20 mb-4"></i>
            <p className="text-2xl font-bold opacity-40">No dishes found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MenuPage;
