
import React, { useState } from 'react';
import { Product, Category } from '../types';
import { CATEGORIES, DRINK_TYPES } from '../constants';
import { generateFoodDescription } from '../services/geminiService';

interface AdminDashboardProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ products, setProducts }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [isGeneratingDesc, setIsGeneratingDesc] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    category: Category.LUNCH,
    isAvailable: true,
    image: 'https://picsum.photos/seed/' + Math.random() + '/800/600'
  });

  const handleSave = () => {
    if (!newProduct.name || !newProduct.price) return;
    
    const product: Product = {
      id: Date.now().toString(),
      name: newProduct.name!,
      description: newProduct.description!,
      price: Number(newProduct.price),
      category: newProduct.category as Category,
      image: newProduct.image!,
      isAvailable: true,
      createdAt: Date.now()
    };

    const updated = [product, ...products];
    setProducts(updated);
    localStorage.setItem('bme_products', JSON.stringify(updated));
    setIsAdding(false);
    setNewProduct({
      name: '',
      description: '',
      price: 0,
      category: Category.LUNCH,
      isAvailable: true,
      image: 'https://picsum.photos/seed/' + Math.random() + '/800/600'
    });
  };

  const handleDelete = (id: string) => {
    if (!confirm('Are you sure?')) return;
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    localStorage.setItem('bme_products', JSON.stringify(updated));
  };

  const handleGenerateAI = async () => {
    if (!newProduct.name) return alert("Please enter a name first.");
    setIsGeneratingDesc(true);
    const desc = await generateFoodDescription(newProduct.name, newProduct.category || 'Food');
    setNewProduct({ ...newProduct, description: desc });
    setIsGeneratingDesc(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-extrabold">Admin <span className="text-orange-500">Dashboard</span></h1>
          <p className="opacity-60">Manage products and restaurant settings</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-orange-600 hover:bg-orange-700 px-8 py-3 rounded-2xl font-bold transition flex items-center gap-2"
        >
          <i className="fas fa-plus"></i> Add Product
        </button>
      </div>

      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setIsAdding(false)}></div>
          <div className="relative glass p-10 rounded-[2.5rem] w-full max-w-2xl shadow-2xl space-y-6">
            <h2 className="text-3xl font-bold">Add New Product</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold opacity-70">Dish Name</label>
                <input 
                  type="text" 
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  value={newProduct.name}
                  onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold opacity-70">Price ($)</label>
                <input 
                  type="number" 
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  value={newProduct.price}
                  onChange={e => setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold opacity-70">Category</label>
                <select 
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl outline-none"
                  value={newProduct.category}
                  onChange={e => setNewProduct({...newProduct, category: e.target.value as Category})}
                >
                  {CATEGORIES.map(c => <option key={c} value={c} className="bg-neutral-900">{c}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold opacity-70">Image URL</label>
                <input 
                  type="text" 
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  value={newProduct.image}
                  onChange={e => setNewProduct({...newProduct, image: e.target.value})}
                />
              </div>
              <div className="md:col-span-2 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-semibold opacity-70">Description</label>
                  <button 
                    onClick={handleGenerateAI}
                    disabled={isGeneratingDesc}
                    className="text-xs bg-purple-600 hover:bg-purple-700 px-3 py-1 rounded-lg transition flex items-center gap-1"
                  >
                    {isGeneratingDesc ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-magic"></i>}
                    Generate with Gemini
                  </button>
                </div>
                <textarea 
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  value={newProduct.description}
                  onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                ></textarea>
              </div>
            </div>

            <div className="flex justify-end gap-4 pt-4">
              <button 
                onClick={() => setIsAdding(false)}
                className="px-8 py-3 glass hover:bg-white/10 rounded-xl transition"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                className="px-8 py-3 bg-orange-600 hover:bg-orange-700 rounded-xl font-bold transition shadow-lg shadow-orange-900/40"
              >
                Save Dish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product List Table */}
      <div className="glass rounded-[2rem] overflow-hidden shadow-2xl">
        <table className="w-full text-left border-collapse">
          <thead className="glass border-b border-white/10">
            <tr>
              <th className="p-6 font-bold uppercase tracking-widest text-xs opacity-60">Image</th>
              <th className="p-6 font-bold uppercase tracking-widest text-xs opacity-60">Product</th>
              <th className="p-6 font-bold uppercase tracking-widest text-xs opacity-60">Category</th>
              <th className="p-6 font-bold uppercase tracking-widest text-xs opacity-60">Price</th>
              <th className="p-6 font-bold uppercase tracking-widest text-xs opacity-60">Status</th>
              <th className="p-6 font-bold uppercase tracking-widest text-xs opacity-60">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {products.map(p => (
              <tr key={p.id} className="hover:bg-white/5 transition">
                <td className="p-6">
                  <img src={p.image} className="w-16 h-16 object-cover rounded-xl shadow-lg" alt={p.name} />
                </td>
                <td className="p-6">
                  <p className="font-bold text-lg">{p.name}</p>
                  <p className="text-xs opacity-50 truncate max-w-xs">{p.description}</p>
                </td>
                <td className="p-6">
                  <span className="bg-white/10 px-3 py-1 rounded-full text-xs font-bold">{p.category}</span>
                </td>
                <td className="p-6 font-bold text-orange-400">${p.price.toFixed(2)}</td>
                <td className="p-6">
                  <span className={`flex items-center gap-2 text-xs font-bold ${p.isAvailable ? 'text-green-400' : 'text-red-400'}`}>
                    <div className={`w-2 h-2 rounded-full ${p.isAvailable ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`}></div>
                    {p.isAvailable ? 'Available' : 'Sold Out'}
                  </span>
                </td>
                <td className="p-6">
                  <div className="flex gap-4">
                    <button className="text-blue-400 hover:text-blue-300">
                      <i className="fas fa-edit"></i>
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="text-red-400 hover:text-red-300">
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;
