
import { Product, Category } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Classic Breakfast Plate',
    description: 'Fresh organic eggs, crispy bacon, sourdough toast, and roasted tomatoes.',
    price: 12.50,
    image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=800',
    category: Category.BREAKFAST,
    isAvailable: true,
    createdAt: Date.now()
  },
  {
    id: '2',
    name: 'Grilled Salmon Salad',
    description: 'Wild-caught salmon, seasonal greens, avocado, and lemon vinaigrette.',
    price: 18.00,
    image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&q=80&w=800',
    category: Category.LUNCH,
    isAvailable: true,
    createdAt: Date.now()
  },
  {
    id: '3',
    name: 'Truffle Mushroom Pasta',
    description: 'Handmade fettuccine with creamy mushroom sauce and fresh truffle shavings.',
    price: 22.00,
    image: 'https://images.unsplash.com/photo-1473093226795-af9932fe5856?auto=format&fit=crop&q=80&w=800',
    category: Category.DINNER,
    isAvailable: true,
    createdAt: Date.now()
  },
  {
    id: '4',
    name: 'Aged Cabernet Sauvignon',
    description: 'Full-bodied red wine with notes of dark berries and oak.',
    price: 45.00,
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&q=80&w=800',
    category: Category.DRINKS,
    subCategory: 'Wine',
    isAvailable: true,
    createdAt: Date.now()
  },
  {
    id: '5',
    name: 'Craft IPA',
    description: 'Local brewery citrusy IPA with a crisp finish.',
    price: 8.50,
    image: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&q=80&w=800',
    category: Category.DRINKS,
    subCategory: 'Beer',
    isAvailable: true,
    createdAt: Date.now()
  },
  {
    id: '6',
    name: 'Fresh Orange Juice',
    description: '100% freshly squeezed Valencia oranges.',
    price: 5.50,
    image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&q=80&w=800',
    category: Category.DRINKS,
    subCategory: 'Juice',
    isAvailable: true,
    createdAt: Date.now()
  }
];

export const COUNTRIES = [
  { name: 'USA', code: '+1' },
  { name: 'UK', code: '+44' },
  { name: 'Canada', code: '+1' },
  { name: 'Nigeria', code: '+234' },
  { name: 'Kenya', code: '+254' },
  { name: 'South Africa', code: '+27' },
  { name: 'France', code: '+33' },
  { name: 'Germany', code: '+49' }
];

export const CATEGORIES = Object.values(Category);
export const DRINK_TYPES = ['Wine', 'Juice', 'Beer', 'Soft Drinks', 'Other'];
