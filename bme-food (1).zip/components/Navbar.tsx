
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { User, Role } from '../types';

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
  cartCount: number;
  onCartClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout, cartCount, onCartClick }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Menu', path: '/menu' },
    ...(user?.role === Role.ADMIN ? [{ name: 'Admin', path: '/admin' }] : []),
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-40 glass border-b border-white/10 shadow-lg px-4 lg:px-12 py-3">
      <div className="flex justify-between items-center max-w-7xl mx-auto">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="bg-orange-600 w-10 h-10 rounded-xl flex items-center justify-center shadow-lg group-hover:rotate-12 transition-transform duration-300">
            <span className="font-bold text-lg">BME</span>
          </div>
          <span className="text-2xl font-bold tracking-tight bg-gradient-to-r from-white to-orange-200 bg-clip-text text-transparent">Food</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map(link => (
            <Link 
              key={link.path} 
              to={link.path}
              className={`transition font-medium ${isActive(link.path) ? 'text-orange-500' : 'text-white hover:text-orange-400'}`}
            >
              {link.name}
            </Link>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onCartClick}
            className="relative p-2 glass rounded-full hover:bg-white/20 transition group"
          >
            <i className="fas fa-shopping-basket text-xl group-hover:scale-110 transition"></i>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {user ? (
            <div className="flex items-center gap-3">
              <Link to="/profile" className="hidden sm:block text-sm font-medium hover:text-orange-400 transition">
                Hello, {user.firstName}
              </Link>
              <button 
                onClick={onLogout}
                className="bg-red-500/20 hover:bg-red-500 text-white px-4 py-2 rounded-lg transition border border-red-500/30"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link 
              to="/login"
              className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-2 rounded-lg transition font-semibold shadow-lg shadow-orange-900/20"
            >
              Login
            </Link>
          )}

          {/* Mobile toggle */}
          <button 
            className="md:hidden p-2 text-2xl"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute left-0 right-0 top-full glass-dark border-b border-white/10 p-4 space-y-4 animate-fadeIn">
          {navLinks.map(link => (
            <Link 
              key={link.path} 
              to={link.path}
              onClick={() => setIsMobileMenuOpen(false)}
              className="block py-2 text-lg font-medium border-b border-white/5"
            >
              {link.name}
            </Link>
          ))}
          {!user && (
            <Link to="/login" onClick={() => setIsMobileMenuOpen(false)} className="block py-2 text-orange-400">Login / Register</Link>
          )}
          {user && (
            <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)} className="block py-2">Profile</Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
