
import React from 'react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemove: (id: string) => void;
  onUpdateQty: (id: string, delta: number) => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, items, onRemove, onUpdateQty }) => {
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <div className={`fixed right-0 top-0 bottom-0 w-full max-w-md glass-dark z-50 transform transition-transform duration-500 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'} shadow-2xl flex flex-col`}>
        <div className="p-6 border-b border-white/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <i className="fas fa-shopping-basket text-orange-500"></i>
            Your Basket
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition">
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>

        <div className="flex-grow overflow-y-auto p-6 space-y-6">
          {items.length === 0 ? (
            <div className="text-center py-20 opacity-50">
              <i className="fas fa-utensils text-6xl mb-4"></i>
              <p className="text-lg">Your basket is empty.</p>
              <button 
                onClick={onClose}
                className="mt-4 text-orange-500 font-semibold hover:underline"
              >
                Go browse the menu
              </button>
            </div>
          ) : (
            items.map(item => (
              <div key={item.id} className="flex gap-4 glass p-3 rounded-2xl">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-20 h-20 object-cover rounded-xl"
                />
                <div className="flex-grow">
                  <div className="flex justify-between">
                    <h3 className="font-semibold">{item.name}</h3>
                    <button 
                      onClick={() => onRemove(item.id)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <i className="fas fa-trash-alt text-sm"></i>
                    </button>
                  </div>
                  <p className="text-sm opacity-70 mb-2">${item.price.toFixed(2)}</p>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => onUpdateQty(item.id, -1)}
                      className="w-7 h-7 flex items-center justify-center glass rounded-lg hover:bg-white/20"
                    >
                      <i className="fas fa-minus text-xs"></i>
                    </button>
                    <span className="font-bold w-4 text-center">{item.quantity}</span>
                    <button 
                      onClick={() => onUpdateQty(item.id, 1)}
                      className="w-7 h-7 flex items-center justify-center glass rounded-lg hover:bg-white/20"
                    >
                      <i className="fas fa-plus text-xs"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {items.length > 0 && (
          <div className="p-6 border-t border-white/10 space-y-4">
            <div className="flex justify-between text-xl font-bold">
              <span>Total</span>
              <span className="text-orange-500">${total.toFixed(2)}</span>
            </div>
            <button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-4 rounded-2xl font-bold text-lg transition shadow-xl shadow-orange-900/40">
              Proceed to Order
            </button>
            <p className="text-center text-xs opacity-50">Fast delivery available. No online payment required yet.</p>
          </div>
        )}
      </div>
    </>
  );
};

export default CartDrawer;
