
export enum Role {
  USER = 'user',
  ADMIN = 'admin'
}

export enum Category {
  BREAKFAST = 'Breakfast',
  LUNCH = 'Lunch',
  DINNER = 'Dinner',
  DRINKS = 'Drinks'
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: Category;
  subCategory?: string;
  isAvailable: boolean;
  createdAt: number;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  country: string;
  role: Role;
}

export interface CartItem extends Product {
  quantity: number;
}
