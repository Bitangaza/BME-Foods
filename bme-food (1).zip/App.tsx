
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { User, Product, CartItem, Role, Category } from './types';
import { INITIAL_PRODUCTS } from './constants';

// Pages
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import MenuPage from './pages/MenuPage';
import AdminDashboard from './pages/AdminDashboard';
import ProfilePage from './pages/ProfilePage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';

// Components
import Navbar from './components/Navbar';
import CartDrawer from './components/CartDrawer';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initial data load
    const savedProducts = localStorage.getItem('bme_products');
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    } else {
      setProducts(INITIAL_PRODUCTS);
      localStorage.setItem('bme_products', JSON.stringify(INITIAL_PRODUCTS));
    }

    const savedUser = localStorage.getItem('bme_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('bme_user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('bme_user');
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  if (isLoading) return <div className="h-screen flex items-center justify-center"><i className="fas fa-spinner fa-spin text-4xl"></i></div>;

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col relative overflow-x-hidden">
        <Navbar 
          user={user} 
          onLogout={handleLogout} 
          cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
          onCartClick={() => setIsCartOpen(true)}
        />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/menu" element={<MenuPage products={products} addToCart={addToCart} />} />
            <Route path="/login" element={user ? <Navigate to="/menu" /> : <LoginPage onLogin={handleLogin} />} />
            <Route path="/register" element={user ? <Navigate to="/menu" /> : <RegisterPage onLogin={handleLogin} />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            
            <Route path="/profile" element={user ? <ProfilePage user={user} setUser={setUser} /> : <Navigate to="/login" />} />
            
            <Route 
              path="/admin" 
              element={
                user?.role === Role.ADMIN ? (
                  <AdminDashboard products={products} setProducts={setProducts} />
                ) : (
                  <Navigate to="/" />
                )
              } 
            />
          </Routes>
        </main>

        <footer className="glass-dark mt-auto py-8 text-center">
          <div className="flex justify-center items-center gap-2 text-2xl font-bold mb-4">
            <span className="bg-orange-500 text-white p-2 rounded-lg">BME</span>
            <span>Food</span>
          </div>
          <p className="opacity-70">&copy; {new Date().getFullYear()} BME Food International. All Rights Reserved.</p>
          <div className="flex justify-center gap-6 mt-4 opacity-50">
            <i className="fab fa-facebook hover:text-orange-500 cursor-pointer transition"></i>
            <i className="fab fa-instagram hover:text-orange-500 cursor-pointer transition"></i>
            <i className="fab fa-twitter hover:text-orange-500 cursor-pointer transition"></i>
          </div>
        </footer>

        <CartDrawer 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          items={cart} 
          onRemove={removeFromCart}
          onUpdateQty={updateQuantity}
        />
      </div>
    </HashRouter>
  );
};

export default App;
