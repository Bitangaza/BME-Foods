
import { GoogleGenAI, Type } from "@google/genai";

/* Correct initialization: use apiKey property and process.env.API_KEY directly */
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateFoodDescription = async (foodName: string, category: string): Promise<string> => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a mouth-watering, elegant, and professional description for a dish named "${foodName}" in the "${category}" category. Keep it under 150 characters. Use descriptive words that appeal to the senses.`,
      config: {
        temperature: 0.7,
        topP: 0.95,
        topK: 40,
      }
    });

    /* Access .text property directly, do not call it as a method */
    return response.text?.trim() || "A delicious addition to our menu.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Chef's special preparation featuring premium ingredients and seasonal flavors.";
  }
};

export const suggestDishes = async (preferences: string): Promise<any[]> => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on the following user preferences: "${preferences}", suggest 3 creative dish names with descriptions and categories (Breakfast, Lunch, Dinner, or Drinks). Return strictly as a JSON array of objects.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ["name", "description", "category"]
          }
        }
      }
    });

    /* Access .text property and trim before parsing JSON */
    const jsonStr = response.text?.trim() || '[]';
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Gemini Suggestion Error:", error);
    return [];
  }
};
